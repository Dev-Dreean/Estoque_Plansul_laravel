-- SINCRONIZAÇÃO UF KINGHOST
-- Corrigir coluna patr.UF baseado na hierarquia: projeto.UF → local.UF → fallback

-- UPDATE 1: Usar UF do projeto (via locais_projeto + tabfant)
UPDATE patr p
INNER JOIN locais_projeto lp ON p.CDLOCAL = lp.cdlocal
INNER JOIN tabfant pj ON lp.tabfant_id = pj.id
SET p.UF = pj.UF
WHERE (p.UF IS NULL OR p.UF = '')
  AND pj.UF IS NOT NULL
  AND pj.UF != '';

-- UPDATE 2: Usar UF do local (quando projeto.UF é NULL)
UPDATE patr p
INNER JOIN locais_projeto lp ON p.CDLOCAL = lp.cdlocal
SET p.UF = lp.UF
WHERE (p.UF IS NULL OR p.UF = '')
  AND lp.UF IS NOT NULL
  AND lp.UF != '';

-- UPDATE 3: Fallback 'SC' para SEDE quando nada preencher (tabfant_id = 10000002 é SEDE)
UPDATE patr p
INNER JOIN locais_projeto lp ON p.CDLOCAL = lp.cdlocal
SET p.UF = 'SC'
WHERE (p.UF IS NULL OR p.UF = '')
  AND lp.tabfant_id = 10000002;

-- VERIFICAÇÃO: Mostrar distribuição de UF após sincronização
SELECT 'Distribuição UF após sincronização:' as info;
SELECT UF, COUNT(*) as qtd FROM patr GROUP BY UF ORDER BY qtd DESC;
