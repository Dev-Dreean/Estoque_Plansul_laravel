<?php
/**
 * one-off: Reenviar último status de solicitações que não receberam notificação
 * 
 * Propósito: Resync emails para solicitações que ficaram sem notificação
 * Uso: php82 storage/app/one_off_reenviar_ultimo_status.php
 * 
 * Ambiente obrigatório:
 *   REENVIO_FROM - Data/hora de corte (padrão: 2026-04-07 11:25:00)
 *   DRY_RUN - 0 para executar, 1 para simular (padrão: 1)
 */

require_once __DIR__ . '/../../bootstrap/app.php';

use App\Models\SolicitacaoBem;
use App\Services\SolicitacaoBemEmailService;

$app = require_once __DIR__ . '/../../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

// ============================================================================
// CONFIG
// ============================================================================

$dryRun = (int) (getenv('DRY_RUN') ?: '1') === 1;
$reenvioDe = getenv('REENVIO_FROM') ?: '2026-04-07 11:25:00';
$timestamp = date('Y-m-d H:i:s');

echo "[REENVIO] from={$reenvioDe} dryRun={$dryRun} timestamp={$timestamp}\n";

// ============================================================================
// MAPEAMENTO: Status → Evento
// ============================================================================

$mapEvento = static function (SolicitacaoBem $s): ?string {
    return match ($s->status) {
        SolicitacaoBem::STATUS_PENDENTE => 'criada',
        SolicitacaoBem::STATUS_AGUARDANDO_CONFIRMACAO => 'triagem_concluida',
        SolicitacaoBem::STATUS_LIBERACAO => 'autorizacao_liberacao',
        SolicitacaoBem::STATUS_CONFIRMADO => 'pedido_enviado',
        SolicitacaoBem::STATUS_NAO_ENVIADO => 'pedido_nao_enviado',
        SolicitacaoBem::STATUS_NAO_RECEBIDO => 'pedido_nao_recebido',
        SolicitacaoBem::STATUS_RECEBIDO => 'pedido_recebido',
        SolicitacaoBem::STATUS_CANCELADO => 'solicitacao_cancelada',
        default => null,
    };
};

// ============================================================================
// BUSCAR SOLICITAÇÕES A REENVIAR
// ============================================================================

try {
    $solicitacoes = SolicitacaoBem::query()
        ->where('created_at', '>=', $reenvioDe)
        ->orderBy('id')
        ->get();

    echo "[REENVIO] total=" . $solicitacoes->count() . "\n";

    if ($solicitacoes->isEmpty()) {
        echo "[REENVIO] Nenhuma solicitação encontrada após {$reenvioDe}\n";
        exit(0);
    }

    // ========================================================================
    // REENVIAR EMAILS
    // ========================================================================

    $emailService = app(SolicitacaoBemEmailService::class);
    $okCount = 0;
    $failCount = 0;
    $results = [];

    foreach ($solicitacoes as $s) {
        $evento = $mapEvento($s);

        if (!$evento) {
            echo "[REENVIO] SKIP|{$s->id}|{$s->status}|evento_desconhecido\n";
            $failCount++;
            continue;
        }

        if ($dryRun) {
            echo "[REENVIO] DRY|{$s->id}|{$s->status}|{$evento}\n";
            $results[] = ['id' => $s->id, 'status' => 'DRY', 'evento' => $evento];
            continue;
        }

        try {
            $emailService->agendarNotificacaoFluxo($s, $evento);
            echo "[REENVIO] OK|{$s->id}|{$s->status}|{$evento}\n";
            $okCount++;
            $results[] = ['id' => $s->id, 'status' => 'OK', 'evento' => $evento];
        } catch (Exception $e) {
            echo "[REENVIO] FAIL|{$s->id}|{$s->status}|{$e->getMessage()}\n";
            $failCount++;
            $results[] = ['id' => $s->id, 'status' => 'FAIL', 'evento' => $evento, 'error' => $e->getMessage()];
        }
    }

    // ========================================================================
    // RESUMO
    // ========================================================================

    echo "\n[REENVIO] fim ok={$okCount} fail={$failCount}\n";

    exit($failCount > 0 ? 1 : 0);

} catch (Exception $e) {
    echo "[REENVIO] ERRO: " . $e->getMessage() . "\n";
    exit(2);
}
