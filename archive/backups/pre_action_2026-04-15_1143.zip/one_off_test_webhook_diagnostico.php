<?php
/**
 * one-off: Teste robusto de webhook Power Automate
 * 
 * Propósito: Diagnosticar comunicação completa com Power Automate
 * Uso: php82 storage/app/one_off_test_webhook_diagnostico.php
 * 
 * Ambiente obrigatório:
 *   WEBHOOK_URL - URL completa do webhook (com sig)
 *   DRY_RUN - 0 para executar, 1 para simular (padrão: 1)
 */

// ============================================================================
// CONFIG
// ============================================================================

$webhookUrl = 'https://default2ece9e6005c6403cbf2423da115415.76.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/46cdb6d67ae54d5f91d027fb6eeddd4f/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=obwvTdwkzO3FD3_FxWb5PkWMi_WyA_Tcs2yPwFZhYMs';

$dryRun = (int) (getenv('DRY_RUN') ?: '0') === 1;
$timestamp = date('Y-m-d H:i:s');
$logPath = __DIR__ . '/one_off_webhook_test_' . date('YmdHis') . '.log';

// ============================================================================
// TESTES
// ============================================================================

$tests = [];

// Teste 1: Webhook simples (apenas identificação)
$tests[] = [
    'name' => 'Teste 1 - Identificação Simples',
    'payload' => [
        'type' => 'test',
        'timestamp' => $timestamp,
        'origin' => 'estoque-laravel',
        'test_id' => 'TEST_001'
    ]
];

// Teste 2: Webhook com dados de solicitação real
$tests[] = [
    'name' => 'Teste 2 - Dados Solicitação (Formato Real)',
    'payload' => [
        'type' => 'notification',
        'timestamp' => $timestamp,
        'solicitacao_id' => 999,
        'solicitante' => 'Teste Diagnóstico',
        'status' => 'PENDENTE',
        'evento' => 'criada',
        'email' => 'teste@example.com',
        'mensagem' => 'Teste de webhook - ignorar esta notificação',
        'origin' => 'estoque-laravel-diagnostico'
    ]
];

// Teste 3: Webhook com campo adicional (stress test)
$tests[] = [
    'name' => 'Teste 3 - Payload Estendido',
    'payload' => [
        'type' => 'notification_extended',
        'timestamp' => $timestamp,
        'solicitacao_id' => 888,
        'solicitante' => 'Teste Estendido',
        'status' => 'CONFIRMADO',
        'evento' => 'liberacao_aprovada',
        'email' => 'teste_extended@example.com',
        'telefone' => '(11) 9999-9999',
        'departamento' => 'TI',
        'valor_estimado' => 5000.00,
        'mensagem' => 'Teste de payload estendido',
        'origin' => 'estoque-laravel-stress'
    ]
];

// ============================================================================
// EXECUÇÃO
// ============================================================================

$results = [];

echo "[WEBHOOK-TEST] ========== DIAGNÓSTICO DE WEBHOOK POWER AUTOMATE ==========\n";
echo "[WEBHOOK-TEST] Data/Hora: {$timestamp}\n";
echo "[WEBHOOK-TEST] Dry Run: " . ($dryRun ? 'SIM (nenhum teste será disparado)' : 'NÃO (testes reais serão executados)') . "\n";
echo "[WEBHOOK-TEST] URL: " . substr($webhookUrl, 0, 100) . "...\n";
echo "[WEBHOOK-TEST] Total de testes: " . count($tests) . "\n";
echo "[WEBHOOK-TEST] ============================================================\n\n";

foreach ($tests as $index => $test) {
    $testNum = $index + 1;
    $testName = $test['name'];
    $payload = $test['payload'];
    
    echo "[TESTE-{$testNum}] {$testName}\n";
    echo "[TESTE-{$testNum}] Payload: " . json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    
    if ($dryRun) {
        echo "[TESTE-{$testNum}] ⏸️  DRY RUN - não executando\n\n";
        $results[$testNum] = [
            'test' => $testName,
            'dry_run' => true,
            'status' => 'SIMULADO',
            'http_status' => null,
            'response' => 'Modo dry-run, execução não realizada'
        ];
        continue;
    }
    
    // Executar teste real
    try {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $webhookUrl,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'User-Agent: EstoquePlansul-WebhookDiagnostico/1.0'
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        $curlErrno = curl_errno($ch);
        
        // curl_close() não é necessário no PHP 8.0+ (resource é auto-fechado)
        
        // Separar headers da resposta
        [$headers, $body] = explode("\r\n\r\n", $response, 2);
        
        if ($curlError) {
            echo "[TESTE-{$testNum}] ❌ ERRO CURL: {$curlError} (errno={$curlErrno})\n\n";
            $results[$testNum] = [
                'test' => $testName,
                'dry_run' => false,
                'status' => 'ERRO_CONEXAO',
                'http_status' => null,
                'error' => $curlError,
                'errno' => $curlErrno
            ];
        } else {
            $statusText = $httpCode === 202 ? '✅ SUCESSO' : '⚠️ RESPOSTA ANÔMALA';
            echo "[TESTE-{$testNum}] HTTP Status: {$httpCode} {$statusText}\n";
            echo "[TESTE-{$testNum}] Headers (primeiras linhas):\n";
            $headerLines = array_slice(explode("\r\n", $headers), 0, 5);
            foreach ($headerLines as $line) {
                if ($line) echo "[TESTE-{$testNum}]   {$line}\n";
            }
            echo "[TESTE-{$testNum}] Body (até 500 chars): " . substr($body, 0, 500) . "\n\n";
            
            $results[$testNum] = [
                'test' => $testName,
                'dry_run' => false,
                'status' => $httpCode === 202 ? 'OK' : 'ANÔMALO',
                'http_status' => $httpCode,
                'headers' => $headers,
                'body' => substr($body, 0, 1000)
            ];
        }
    } catch (Exception $e) {
        echo "[TESTE-{$testNum}] ❌ EXCEÇÃO: " . $e->getMessage() . "\n\n";
        $results[$testNum] = [
            'test' => $testName,
            'dry_run' => false,
            'status' => 'EXCECAO',
            'error' => $e->getMessage()
        ];
    }
}

// ============================================================================
// RESUMO E LOG
// ============================================================================

echo "[WEBHOOK-TEST] ============================================================\n";
echo "[WEBHOOK-TEST] RESUMO DOS TESTES\n";
echo "[WEBHOOK-TEST] ============================================================\n\n";

$successCount = 0;
$failCount = 0;

foreach ($results as $testNum => $result) {
    $status = $result['status'];
    $symbol = match($status) {
        'OK' => '✅',
        'SIMULADO' => '⏸️ ',
        default => '❌'
    };
    
    echo "[RESUMO] {$symbol} Teste {$testNum}: {$result['test']}\n";
    echo "[RESUMO]    Status: {$status}\n";
    if (isset($result['http_status'])) {
        echo "[RESUMO]    HTTP: {$result['http_status']}\n";
    }
    
    if ($status === 'OK') $successCount++;
    else if ($status !== 'SIMULADO') $failCount++;
}

echo "\n[WEBHOOK-TEST] ============================================================\n";
echo "[WEBHOOK-TEST] TOTAL: Testes={" . count($results) . "} OK={$successCount} FAIL={$failCount}\n";
echo "[WEBHOOK-TEST] Log salvo em: {$logPath}\n";
echo "[WEBHOOK-TEST] ============================================================\n";

// Salvar log
$logContent = "[{$timestamp}] WEBHOOK DIAGNOSTICO TEST\n";
$logContent .= "Dry Run: " . ($dryRun ? 'SIM' : 'NÃO') . "\n";
$logContent .= "URL: {$webhookUrl}\n";
$logContent .= "Testes Executados: " . count($results) . "\n";
$logContent .= "Sucessos: {$successCount}\n";
$logContent .= "Falhas: {$failCount}\n\n";
$logContent .= json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

file_put_contents($logPath, $logContent);

echo "\n✅ Diagnóstico completo.\n";

// Retorno de exit code
exit($failCount > 0 ? 1 : 0);
