<?php
/**
 * one-off: Reenviar emails das solicitações para email de teste
 * 
 * Propósito: Diagnosticar se emails estão sendo gerados e enviados
 * Uso: php82 storage/app/one_off_reenviar_para_suporte.php
 * 
 * Ambiente obrigatório:
 *   DRY_RUN - 0 para executar, 1 para simular (padrão: 1)
 *   TEST_EMAIL - Email destino (padrão: suporte.dev@plansul.com.br)
 */

require_once __DIR__ . '/../../bootstrap/app.php';

use App\Models\SolicitacaoBem;
use Illuminate\Support\Facades\Mail;
use Illuminate\Mail\Message;

$app = require_once __DIR__ . '/../../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

// ============================================================================
// CONFIG
// ============================================================================

$dryRun = (int) (getenv('DRY_RUN') ?: '1') === 1;
$testEmail = getenv('TEST_EMAIL') ?: 'suporte.dev@plansul.com.br';
$solicitacaoIds = [32, 33, 34, 35, 36];
$timestamp = date('Y-m-d H:i:s');

echo "[TEST-EMAIL] Iniciando reenvio de emails para teste\n";
echo "[TEST-EMAIL] Timestamp: {$timestamp}\n";
echo "[TEST-EMAIL] Email destino: {$testEmail}\n";
echo "[TEST-EMAIL] Dry Run: " . ($dryRun ? 'SIM' : 'NÃO') . "\n";
echo "[TEST-EMAIL] Solicitações: " . implode(', ', $solicitacaoIds) . "\n\n";

// ============================================================================
// MAPEAMENTO: Status → Evento
// ============================================================================

$mapEvento = static function (SolicitacaoBem $s): ?string {
    return match ($s->status) {
        SolicitacaoBem::STATUS_PENDENTE => 'criada',
        SolicitacaoBem::STATUS_AGUARDANDO_CONFIRMACAO => 'triagem_concluida',
        SolicitacaoBem::STATUS_LIBERACAO => 'autorizacao_liberacao',
        SolicitacaoBem::STATUS_CONFIRMADO => 'pedido_enviado',
        SolicitacaoBem::STATUS_NAO_ENVIADO => 'pedido_nao_enviado',
        SolicitacaoBem::STATUS_NAO_RECEBIDO => 'pedido_nao_recebido',
        SolicitacaoBem::STATUS_RECEBIDO => 'pedido_recebido',
        SolicitacaoBem::STATUS_CANCELADO => 'solicitacao_cancelada',
        default => null,
    };
};

// ============================================================================
// BUSCAR SOLICITAÇÕES
// ============================================================================

try {
    $solicitacoes = SolicitacaoBem::query()
        ->whereIn('id', $solicitacaoIds)
        ->orderBy('id')
        ->get();

    if ($solicitacoes->isEmpty()) {
        echo "[TEST-EMAIL] Nenhuma solicitação encontrada\n";
        exit(0);
    }

    echo "[TEST-EMAIL] Total de solicitações encontradas: " . $solicitacoes->count() . "\n\n";

    // ========================================================================
    // ENVIAR EMAILS
    // ========================================================================

    $okCount = 0;
    $failCount = 0;

    foreach ($solicitacoes as $s) {
        $evento = $mapEvento($s);

        if (!$evento) {
            echo "[TEST-EMAIL] SKIP|{$s->id}|Status desconhecido: {$s->status}\n";
            $failCount++;
            continue;
        }

        // Construir assunto e corpo baseado no evento
        $subjects = [
            'criada' => 'Solicitação de Bem #{id} - CRIADA',
            'triagem_concluida' => 'Solicitação de Bem #{id} - Triagem Concluída',
            'autorizacao_liberacao' => 'Solicitação de Bem #{id} - Aguardando Autorização',
            'liberacao_aprovada' => 'Solicitação de Bem #{id} - LIBERADA',
            'pedido_enviado' => 'Solicitação de Bem #{id} - Pedido Enviado',
            'pedido_nao_enviado' => 'Solicitação de Bem #{id} - Pedido NÃO Enviado',
            'pedido_nao_recebido' => 'Solicitação de Bem #{id} - Pedido NÃO Recebido',
            'pedido_recebido' => 'Solicitação de Bem #{id} - Bem Recebido',
            'solicitacao_cancelada' => 'Solicitação de Bem #{id} - CANCELADA',
        ];

        $subject = strtr($subjects[$evento] ?? 'Notificação', ['#id' => $s->id]);
        
        $solicitanteNome = $s->solicitante_nome ?: 'N/A';
        $dataCriacao = $s->created_at->format('d/m/Y H:i:s');
        
        $body = <<<HTML
<html>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">

<h2 style="color: #2c3e50;">Solicitação de Bem #{$s->id}</h2>

<div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
    <p><strong>🔔 Teste de Email - Suporte</strong></p>
    <p>Esta é uma notificação de teste gerada pelo sistema para diagnóstico.</p>
    <p><strong>Evento:</strong> {$evento}</p>
    <p><strong>Status atual:</strong> {$s->status}</p>
    <p><strong>Data/Hora geração:</strong> {$timestamp}</p>
</div>

<div style="margin: 20px 0;">
    <p><strong>Informações da Solicitação:</strong></p>
    <ul>
        <li><strong>ID:</strong> {$s->id}</li>
        <li><strong>Solicitante:</strong> {$solicitanteNome}</li>
        <li><strong>Status:</strong> {$s->status}</li>
        <li><strong>Data Criação:</strong> {$dataCriacao}</li>
    </ul>
</div>

<hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">

<p style="color: #7f8c8d; font-size: 12px;">
    ⚠️ Este é um email de teste. Se você recebeu este email, significa que o sistema de notificações está funcionando corretamente.
</p>

</body>
</html>
HTML;

        if ($dryRun) {
            echo "[TEST-EMAIL] DRY|{$s->id}|{$evento}|Subject: {$subject}\n";
            continue;
        }

        try {
            Mail::send([], [], function (Message $message) use ($testEmail, $subject, $body) {
                $message
                    ->to($testEmail)
                    ->subject($subject)
                    ->html($body);
            });

            echo "[TEST-EMAIL] OK|{$s->id}|{$evento}|Enviado para {$testEmail}\n";
            $okCount++;
        } catch (Exception $e) {
            echo "[TEST-EMAIL] FAIL|{$s->id}|{$evento}|Erro: {$e->getMessage()}\n";
            $failCount++;
        }
    }

    // ========================================================================
    // RESUMO
    // ========================================================================

    echo "\n[TEST-EMAIL] ════════════════════════════════════════════\n";
    echo "[TEST-EMAIL] Sucesso: {$okCount}\n";
    echo "[TEST-EMAIL] Falhas: {$failCount}\n";
    echo "[TEST-EMAIL] Total: {$solicitacoes->count()}\n";
    echo "[TEST-EMAIL] Email destino: {$testEmail}\n";
    echo "[TEST-EMAIL] ════════════════════════════════════════════\n";

    exit($failCount > 0 ? 1 : 0);

} catch (Exception $e) {
    echo "[TEST-EMAIL] ERRO GERAL: " . $e->getMessage() . "\n";
    exit(2);
}
