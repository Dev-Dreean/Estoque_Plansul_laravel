<?php
// Script para analisar o arquivo de importação em detalhes

$importFile = __DIR__ . '/../storage/imports/Importe anterior/PATRIMONIO.TXT';

echo "\n========================================\n";
echo "ANÁLISE DETALHADA DO ARQUIVO\n";
echo "========================================\n";

$handle = fopen($importFile, 'r');
$lineCount = 0;
$validDataLines = 0;
$headerLines = 0;
$separatorLines = 0;
$emptyLines = 0;
$ids = [];
$duplicateIds = [];

while (($line = fgets($handle)) !== false) {
    $lineCount++;
    $trimmedLine = trim($line);
    
    // Contar tipos de linhas
    if (empty($trimmedLine)) {
        $emptyLines++;
        continue;
    }
    
    if (preg_match('/^={4,}/', $trimmedLine)) {
        $separatorLines++;
        continue;
    }
    
    if (preg_match('/^NUPATRIMONIO\s+SITUACAO/i', $trimmedLine)) {
        $headerLines++;
        continue;
    }
    
    // Tentar extrair NUPATRIMONIO
    if (preg_match('/^\s*(\d+)\s+/u', $trimmedLine, $m)) {
        $id = intval($m[1]);
        if ($id > 0) {
            $validDataLines++;
            if (isset($ids[$id])) {
                $duplicateIds[$id] = ($duplicateIds[$id] ?? 1) + 1;
            } else {
                $ids[$id] = 1;
            }
        }
    }
}
fclose($handle);

echo "📄 COMPOSIÇÃO DO ARQUIVO:\n";
echo "   Total de linhas: $lineCount\n";
echo "   - Linhas em branco: $emptyLines\n";
echo "   - Linhas de separador (===): $separatorLines\n";
echo "   - Linhas de header: $headerLines\n";
echo "   - Linhas de dados (com NUPATRIMONIO): $validDataLines\n";
echo "   Total contabilizado: " . ($emptyLines + $separatorLines + $headerLines + $validDataLines) . "\n";

echo "\n📊 PATRIMÔNIOS:\n";
echo "   NUPATRIMONIO únicos: " . count($ids) . "\n";
echo "   Registros com dados: $validDataLines\n";

if (count($duplicateIds) > 0) {
    echo "\n⚠️  DUPLICATAS ENCONTRADAS NO ARQUIVO:\n";
    foreach ($duplicateIds as $id => $count) {
        echo "   - NUPATRIMONIO $id: $count registros\n";
    }
    $totalDups = array_sum($duplicateIds);
    echo "   Total de registros duplicados: $totalDups\n";
} else {
    echo "\n✅ Sem duplicatas no arquivo\n";
}

echo "\n✏️  RESUMO:\n";
echo "   - Se considerarmos cada linha de dado como um registro: $validDataLines patrimônios\n";
echo "   - Se considerarmos apenas IDs únicos: " . count($ids) . " patrimônios\n";

// Amostra de IDs
$sampleIds = array_slice(array_keys($ids), 0, 30);
echo "\nAmostra de primeiros 30 NUPATRIMONIO:\n";
echo implode(", ", $sampleIds) . "\n";

exit(0);
