<?php
$path = __DIR__ . '/../storage/imports/Importe anterior/PATRIMONIO.TXT';
if (!file_exists($path)) {
    fwrite(STDERR, "Arquivo não encontrado: $path\n");
    exit(2);
}
$handle = fopen($path, 'r');
if (!$handle) {
    fwrite(STDERR, "Não foi possível abrir o arquivo: $path\n");
    exit(2);
}
$ids = [];
$lineNo = 0;
while (($line = fgets($handle)) !== false) {
    $lineNo++;
    // Buscar NUPATRIMONIO no início da linha (um ou mais dígitos)
    if (preg_match('/^\s*(\d+)\b/u', $line, $m)) {
        $id = $m[1];
        if (!isset($ids[$id])) {
            $ids[$id] = 0;
        }
        $ids[$id]++;
    }
}
fclose($handle);
$totalLines = $lineNo;
$unique = count($ids);
$duplicates = 0;
foreach ($ids as $id => $count) {
    if ($count > 1) $duplicates += $count - 1;
}
echo "Arquivo: $path\n";
echo "Linhas lidas: $totalLines\n";
echo "IDs únicos detectados: $unique\n";
echo "Registros duplicados (mesmo NUPATRIMONIO repetido): $duplicates\n";
// mostrar algumas amostras
$sample = array_slice(array_keys($ids), 0, 20);
echo "Amostra (primeiros 20 NUPATRIMONIO): " . implode(', ', $sample) . "\n";
// Opcional: exportar lista de IDs para um arquivo
$outFile = __DIR__ . '/../storage/imports/patr_ids_from_file.txt';
file_put_contents($outFile, implode("\n", array_keys($ids)));
echo "IDs exportados para: $outFile\n";
exit(0);
