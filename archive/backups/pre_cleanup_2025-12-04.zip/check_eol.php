<?php
$file = 'storage/imports/Importe anterior/PATRIMONIO.TXT';
$lines = file($file);

echo "=== PRIMEIRAS 5 LINHAS COM NEWLINES ===\n\n";
for ($i = 0; $i < 5; $i++) {
    $len = strlen($lines[$i]);
    $eol = (strpos($lines[$i], "\r\n") !== false) ? 'CRLF' : ((strpos($lines[$i], "\n") !== false) ? 'LF' : 'NONE');
    echo "Linha " . ($i+1) . " (comprimento: $len, EOL: $eol)\n";
    if ($i >= 2) {
        echo "  Primeiros 100 chars: " . substr($lines[$i], 0, 100) . "\n";
    }
}

echo "\n=== ANALISA QUANTAS LINHAS SÃO NECESSÁRIAS ===\n";
$lines_ini = file($file, FILE_IGNORE_NEW_LINES);
echo "Com FILE_IGNORE_NEW_LINES: " . count($lines_ini) . " linhas\n";

$lines_com = file($file);
echo "Sem FILE_IGNORE_NEW_LINES: " . count($lines_com) . " linhas\n";
?>
