<?php
// Script para extrair e mostrar os registros duplicados do arquivo

$importFile = __DIR__ . '/../storage/imports/Importe anterior/PATRIMONIO.TXT';

echo "\n========================================\n";
echo "REGISTROS DUPLICADOS NO ARQUIVO\n";
echo "========================================\n";

$handle = fopen($importFile, 'r');
$records = [];
$lineNum = 0;

while (($line = fgets($handle)) !== false) {
    $lineNum++;
    $trimmedLine = trim($line);
    
    // Pular linhas vazias, headers e separadores
    if (empty($trimmedLine) || preg_match('/^={4,}/', $trimmedLine) || preg_match('/^NUPATRIMONIO\s+SITUACAO/i', $trimmedLine)) {
        continue;
    }
    
    // Extrair NUPATRIMONIO
    if (preg_match('/^\s*(\d+)\s+/u', $trimmedLine, $m)) {
        $id = intval($m[1]);
        if ($id > 0) {
            if (!isset($records[$id])) {
                $records[$id] = [];
            }
            $records[$id][] = [
                'line_num' => $lineNum,
                'data' => $trimmedLine,
            ];
        }
    }
}
fclose($handle);

// Encontrar duplicatas
$duplicates = [];
foreach ($records as $id => $entries) {
    if (count($entries) > 1) {
        $duplicates[$id] = $entries;
    }
}

echo "Total de NUPATRIMONIO duplicados: " . count($duplicates) . "\n\n";

// Mostrar cada duplicata
$count = 0;
foreach ($duplicates as $id => $entries) {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "NUPATRIMONIO: $id\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    
    foreach ($entries as $idx => $entry) {
        echo "\n📍 CÓPIA " . ($idx + 1) . " (Linha " . $entry['line_num'] . "):\n";
        echo $entry['data'] . "\n";
    }
    
    echo "\n";
    $count++;
    if ($count >= 10) break;
}

exit(0);
