<?php
require __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\DB;

echo "\n========================================\n";
echo "LIMPEZA E SINCRONIZAÇÃO COM ARQUIVO\n";
echo "========================================\n";

// Arquivo de importação
$importFile = __DIR__ . '/../storage/imports/Importe anterior/PATRIMONIO.TXT';
if (!file_exists($importFile)) {
    echo "❌ Arquivo não encontrado: $importFile\n";
    exit(1);
}

// Ler arquivo e extrair NUPATRIMONIO válidos
$handle = fopen($importFile, 'r');
$validIds = [];
$lineCount = 0;

while (($line = fgets($handle)) !== false) {
    $lineCount++;
    // Buscar NUPATRIMONIO no início (um ou mais dígitos)
    if (preg_match('/^\s*(\d+)\s+/u', $line, $m)) {
        $id = intval($m[1]);
        if ($id > 0) {
            $validIds[$id] = 1;
        }
    }
}
fclose($handle);

$validCount = count($validIds);
echo "\n📄 IDs válidos no arquivo de importação: $validCount\n";

// Contar registros a remover
$toDelete = DB::table('patr')
    ->whereNotIn('NUPATRIMONIO', array_keys($validIds))
    ->count();

echo "🗑️  Registros para REMOVER (não estão no arquivo): $toDelete\n";

if ($toDelete === 0) {
    echo "\n✅ Nenhum registro a remover. BD já está sincronizado!\n";
    exit(0);
}

// Mostrar amostra dos que serão removidos
$sample = DB::table('patr')
    ->whereNotIn('NUPATRIMONIO', array_keys($validIds))
    ->distinct()
    ->limit(20)
    ->pluck('NUPATRIMONIO')
    ->toArray();

echo "   Amostra (primeiros 20): " . implode(', ', $sample) . "\n";

// Iniciar transação
DB::beginTransaction();

try {
    // Remover registros não presentes no arquivo
    $deleted = DB::table('patr')
        ->whereNotIn('NUPATRIMONIO', array_keys($validIds))
        ->delete();
    
    echo "\n✅ Registros removidos: $deleted\n";
    
    // Verificar duplicatas
    $duplicates = DB::table('patr')
        ->select('NUPATRIMONIO', DB::raw('COUNT(*) as count'))
        ->groupBy('NUPATRIMONIO')
        ->having(DB::raw('COUNT(*)'), '>', 1)
        ->get();
    
    $dupCount = $duplicates->count();
    echo "\n🔄 Duplicatas encontradas: $dupCount\n";
    
    if ($dupCount > 0) {
        foreach ($duplicates as $dup) {
            echo "   - NUPATRIMONIO {$dup->NUPATRIMONIO}: {$dup->count} registros\n";
            
            // Manter apenas o primeiro, remover os outros
            $allRecords = DB::table('patr')
                ->where('NUPATRIMONIO', $dup->NUPATRIMONIO)
                ->orderBy('NUSEQPATR', 'asc')
                ->get();
            
            if (count($allRecords) > 1) {
                // Manter o primeiro
                $toKeep = $allRecords[0]->NUSEQPATR;
                $toRemove = array_slice(array_map(fn($r) => $r->NUSEQPATR, $allRecords->toArray()), 1);
                
                $removedDups = DB::table('patr')
                    ->whereIn('NUSEQPATR', $toRemove)
                    ->delete();
                
                echo "      ✅ Mantido NUSEQPATR $toKeep, removidos $removedDups duplicados\n";
            }
        }
    }
    
    // Commit
    DB::commit();
    
    echo "\n========================================\n";
    echo "SINCRONIZAÇÃO CONCLUÍDA\n";
    echo "========================================\n";
    
    // Verificação final
    $finalCount = DB::table('patr')->distinct()->count('NUPATRIMONIO');
    $finalTotal = DB::table('patr')->count();
    
    echo "📊 Estado final do banco:\n";
    echo "   Total de registros: $finalTotal\n";
    echo "   NUPATRIMONIO distintos: $finalCount\n";
    echo "   Esperado no arquivo: $validCount\n";
    
    if ($finalCount === $validCount) {
        echo "\n✅ PERFEITO! BD sincronizado com o arquivo de importação.\n";
    } else {
        echo "\n⚠️  Atenção: Ainda há discrepâncias.\n";
    }
    
    exit(0);
    
} catch (\Exception $e) {
    DB::rollBack();
    echo "\n❌ ERRO - Transação revertida!\n";
    echo "Erro: " . $e->getMessage() . "\n";
    exit(1);
}
