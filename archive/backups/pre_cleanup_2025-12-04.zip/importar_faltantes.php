<?php
require __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\DB;

echo "\n========================================\n";
echo "IMPORTAÇÃO DE PATRIMÔNIOS FALTANTES\n";
echo "========================================\n";

// IDs faltantes a importar
$missingIds = [133838, 139046, 139865, 169501, 179918, 185895];

// Arquivo de importação
$importFile = __DIR__ . '/../storage/imports/Importe anterior/PATRIMONIO.TXT';

// Ler arquivo e extrair dados dos faltantes
$handle = fopen($importFile, 'r');
$fieldsData = [];
$headerLine = '';
$dataRows = [];

while (($line = fgets($handle)) !== false) {
    $line = trim($line);
    
    // Pular linhas vazias
    if (empty($line)) continue;
    
    // Pegar nomes dos campos (header)
    if (preg_match('/^NUPATRIMONIO\s+SITUACAO/i', $line)) {
        $headerLine = $line;
        // Parse header: "NUPATRIMONIO    SITUACAO    MARCA    CDLOCAL    MODELO..."
        // Campos separados por espaços múltiplos (em formato de tabela)
        $fields = preg_split('/\s{4,}/', $line);
        $fieldsData = array_map('trim', $fields);
        continue;
    }
    
    // Pular linhas de separador (===)
    if (preg_match('/^={4,}/', $line)) continue;
    
    // Parse data rows
    if (preg_match('/^(\d+)\s+(.*)$/', $line, $m)) {
        $id = intval($m[1]);
        if (in_array($id, $missingIds)) {
            $dataRows[$id] = $line;
        }
    }
}
fclose($handle);

echo "\n📋 Patrimônios a importar: " . count($dataRows) . "\n";
foreach (array_keys($dataRows) as $id) {
    echo "   - NUPATRIMONIO $id\n";
}

// Dados pré-estruturados dos 6 faltantes (extraídos do arquivo)
// Colunas da tabela patr: NUSEQPATR, NUPATRIMONIO, SITUACAO, TIPO, MARCA, MODELO, CARACTERISTICAS, DIMENSAO, COR, NUSERIE, CDLOCAL, DTAQUISICAO, DTBAIXA, DTGARANTIA, DEHISTORICO, DTLAUDO, DEPATRIMONIO, CDMATRFUNCIONARIO, CDLOCALINTERNO, CDPROJETO, NMPLANTA, USUARIO, DTOPERACAO, FLCONFERIDO, NUMOF, CODOBJETO
$patrimôniosParaImportar = [
    179918 => [
        'SITUACAO' => null,
        'TIPO' => null,
        'MARCA' => null,
        'MODELO' => null,
        'CARACTERISTICAS' => null,
        'DIMENSAO' => null,
        'COR' => null,
        'NUSERIE' => null,
        'CDLOCAL' => 197,
        'DTAQUISICAO' => null,
        'DTBAIXA' => null,
        'DTGARANTIA' => null,
        'DEHISTORICO' => null,
        'DTLAUDO' => null,
        'DEPATRIMONIO' => null,
        'CDMATRFUNCIONARIO' => null,
        'CDLOCALINTERNO' => null,
        'CDPROJETO' => null,
        'NMPLANTA' => null,
        'USUARIO' => 'RYAN',
        'DTOPERACAO' => '2025-07-11',
        'FLCONFERIDO' => 'N',
        'NUMOF' => 45568,
        'CODOBJETO' => 322,
    ],
    139046 => [
        'SITUACAO' => null,
        'TIPO' => null,
        'MARCA' => null,
        'MODELO' => null,
        'CARACTERISTICAS' => null,
        'DIMENSAO' => null,
        'COR' => null,
        'NUSERIE' => null,
        'CDLOCAL' => 407,
        'DTAQUISICAO' => null,
        'DTBAIXA' => null,
        'DTGARANTIA' => null,
        'DEHISTORICO' => null,
        'DTLAUDO' => null,
        'DEPATRIMONIO' => null,
        'CDMATRFUNCIONARIO' => null,
        'CDLOCALINTERNO' => null,
        'CDPROJETO' => null,
        'NMPLANTA' => null,
        'USUARIO' => 'BEA.SC',
        'DTOPERACAO' => '2025-09-03',
        'FLCONFERIDO' => 'N',
        'NUMOF' => 46972,
        'CODOBJETO' => 709,
    ],
    139865 => [
        'SITUACAO' => null,
        'TIPO' => null,
        'MARCA' => null,
        'MODELO' => null,
        'CARACTERISTICAS' => null,
        'DIMENSAO' => null,
        'COR' => null,
        'NUSERIE' => null,
        'CDLOCAL' => 197,
        'DTAQUISICAO' => null,
        'DTBAIXA' => null,
        'DTGARANTIA' => null,
        'DEHISTORICO' => null,
        'DTLAUDO' => null,
        'DEPATRIMONIO' => null,
        'CDMATRFUNCIONARIO' => null,
        'CDLOCALINTERNO' => null,
        'CDPROJETO' => null,
        'NMPLANTA' => null,
        'USUARIO' => 'RYAN',
        'DTOPERACAO' => '2025-07-10',
        'FLCONFERIDO' => 'N',
        'NUMOF' => 44244,
        'CODOBJETO' => 159,
    ],
    133838 => [
        'SITUACAO' => null,
        'TIPO' => null,
        'MARCA' => null,
        'MODELO' => null,
        'CARACTERISTICAS' => null,
        'DIMENSAO' => null,
        'COR' => null,
        'NUSERIE' => null,
        'CDLOCAL' => 664,
        'DTAQUISICAO' => null,
        'DTBAIXA' => null,
        'DTGARANTIA' => null,
        'DEHISTORICO' => null,
        'DTLAUDO' => null,
        'DEPATRIMONIO' => null,
        'CDMATRFUNCIONARIO' => null,
        'CDLOCALINTERNO' => null,
        'CDPROJETO' => null,
        'NMPLANTA' => null,
        'USUARIO' => 'BEA.SC',
        'DTOPERACAO' => '2025-11-17',
        'FLCONFERIDO' => 'N',
        'NUMOF' => 44244,
        'CODOBJETO' => 802,
    ],
    169501 => [
        'SITUACAO' => null,
        'TIPO' => null,
        'MARCA' => null,
        'MODELO' => null,
        'CARACTERISTICAS' => null,
        'DIMENSAO' => null,
        'COR' => null,
        'NUSERIE' => null,
        'CDLOCAL' => 197,
        'DTAQUISICAO' => null,
        'DTBAIXA' => null,
        'DTGARANTIA' => null,
        'DEHISTORICO' => null,
        'DTLAUDO' => null,
        'DEPATRIMONIO' => null,
        'CDMATRFUNCIONARIO' => null,
        'CDLOCALINTERNO' => null,
        'CDPROJETO' => null,
        'NMPLANTA' => null,
        'USUARIO' => 'RYAN',
        'DTOPERACAO' => '2025-01-20',
        'FLCONFERIDO' => 'N',
        'NUMOF' => 44244,
        'CODOBJETO' => 323,
    ],
    185895 => [
        'SITUACAO' => null,
        'TIPO' => null,
        'MARCA' => null,
        'MODELO' => null,
        'CARACTERISTICAS' => null,
        'DIMENSAO' => null,
        'COR' => null,
        'NUSERIE' => null,
        'CDLOCAL' => 999915,
        'DTAQUISICAO' => null,
        'DTBAIXA' => null,
        'DTGARANTIA' => null,
        'DEHISTORICO' => null,
        'DTLAUDO' => null,
        'DEPATRIMONIO' => null,
        'CDMATRFUNCIONARIO' => null,
        'CDLOCALINTERNO' => null,
        'CDPROJETO' => null,
        'NMPLANTA' => null,
        'USUARIO' => 'TIAGOP',
        'DTOPERACAO' => '2025-09-15',
        'FLCONFERIDO' => 'N',
        'NUMOF' => 0,
        'CODOBJETO' => 1029,
    ],
];

// Iniciar transação
DB::beginTransaction();

try {
    $importedCount = 0;
    $skippedCount = 0;
    
    foreach ($patrimôniosParaImportar as $nupatrimonio => $dados) {
        // Verificar se já existe
        $existe = DB::table('patr')->where('NUPATRIMONIO', $nupatrimonio)->exists();
        
        if ($existe) {
            echo "⏭️  NUPATRIMONIO $nupatrimonio já existe no BD (PULADO)\n";
            $skippedCount++;
            continue;
        }
        
        // Inserir novo registro
        try {
            DB::table('patr')->insert([
                'NUPATRIMONIO' => $nupatrimonio,
                'SITUACAO' => $dados['SITUACAO'],
                'TIPO' => $dados['TIPO'],
                'MARCA' => $dados['MARCA'],
                'MODELO' => $dados['MODELO'],
                'CARACTERISTICAS' => $dados['CARACTERISTICAS'],
                'DIMENSAO' => $dados['DIMENSAO'],
                'COR' => $dados['COR'],
                'NUSERIE' => $dados['NUSERIE'],
                'CDLOCAL' => $dados['CDLOCAL'],
                'DTAQUISICAO' => $dados['DTAQUISICAO'],
                'DTBAIXA' => $dados['DTBAIXA'],
                'DTGARANTIA' => $dados['DTGARANTIA'],
                'DEHISTORICO' => $dados['DEHISTORICO'],
                'DTLAUDO' => $dados['DTLAUDO'],
                'DEPATRIMONIO' => $dados['DEPATRIMONIO'],
                'CDMATRFUNCIONARIO' => $dados['CDMATRFUNCIONARIO'],
                'CDLOCALINTERNO' => $dados['CDLOCALINTERNO'],
                'CDPROJETO' => $dados['CDPROJETO'],
                'NMPLANTA' => $dados['NMPLANTA'],
                'USUARIO' => $dados['USUARIO'],
                'DTOPERACAO' => $dados['DTOPERACAO'],
                'FLCONFERIDO' => $dados['FLCONFERIDO'],
                'NUMOF' => $dados['NUMOF'],
                'CODOBJETO' => $dados['CODOBJETO'],
            ]);
            echo "✅ NUPATRIMONIO $nupatrimonio IMPORTADO COM SUCESSO\n";
            $importedCount++;
        } catch (\Exception $e) {
            echo "❌ ERRO ao importar NUPATRIMONIO $nupatrimonio: " . $e->getMessage() . "\n";
            throw $e;
        }
    }
    
    // Commit da transação
    DB::commit();
    
    echo "\n========================================\n";
    echo "RESULTADO DA IMPORTAÇÃO:\n";
    echo "========================================\n";
    echo "✅ Importados com sucesso: $importedCount\n";
    echo "⏭️  Pulados (já existiam): $skippedCount\n";
    echo "\n";
    
    // Verificação final
    $newCount = DB::table('patr')->distinct()->count('NUPATRIMONIO');
    echo "📊 Total de NUPATRIMONIO distintos após importação: $newCount\n";
    
    exit(0);
    
} catch (\Exception $e) {
    DB::rollBack();
    echo "\n❌ ERRO CRÍTICO - Transação revertida!\n";
    echo "Erro: " . $e->getMessage() . "\n";
    exit(1);
}
