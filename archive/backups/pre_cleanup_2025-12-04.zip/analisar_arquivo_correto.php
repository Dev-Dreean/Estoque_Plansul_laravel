<?php

$file = 'storage/imports/Importe anterior/PATRIMONIO.TXT';
$lines = file($file, FILE_IGNORE_NEW_LINES);

// Contar linhas de dados
$data_lines = 0;
$nupatremonios = [];

foreach ($lines as $line_num => $line) {
    if (empty(trim($line))) continue;
    if (strpos($line, '===') !== false) continue;
    if ($line_num == 0) continue; // header
    
    // Extrair o primeiro número (NUPATRIMONIO)
    if (preg_match('/^(\d+)/', trim($line), $matches)) {
        $nu = $matches[1];
        $nupatremonios[$nu][] = $line_num + 1;
        $data_lines++;
    }
}

echo "Total de linhas de dados: $data_lines\n";
echo "Total de NUPATRIMONIO únicos: " . count($nupatremonios) . "\n\n";

// Procurar duplicados
$duplicados = array_filter($nupatremonios, fn($lines) => count($lines) > 1);

echo "NUPATRIMONIO duplicados (" . count($duplicados) . "):\n";
foreach ($duplicados as $nu => $line_nums) {
    echo "  $nu: linhas " . implode(', ', $line_nums) . "\n";
}
