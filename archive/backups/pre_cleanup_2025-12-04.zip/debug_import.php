<?php

$file = 'storage/imports/Importe anterior/PATRIMONIO.TXT';
$lines = file($file, FILE_IGNORE_NEW_LINES);

echo "Total de linhas: " . count($lines) . "\n";
echo "Linha 1 (header): " . substr($lines[0], 0, 80) . "\n";
echo "Linha 2 (sep): " . substr($lines[1], 0, 80) . "\n";
echo "Linha 3: " . substr($lines[2], 0, 80) . "\n\n";

$trimmed = trim($lines[2]);
echo "Trimmed linha 3: " . substr($trimmed, 0, 80) . "\n";

if (preg_match('/^(\d+)/', $trimmed, $m)) {
    echo "NUPATRIMONIO: " . $m[1] . "\n";
} else {
    echo "Nao encontrou numero no inicio\n";
}

$rest = substr($trimmed, strlen((string)$m[1]));
$rest = trim($rest);
echo "\nRest: " . substr($rest, 0, 100) . "\n";

$fields = preg_split('/\s{2,}/', $rest, 16, PREG_SPLIT_NO_EMPTY);
echo "Campos encontrados: " . count($fields) . "\n";
foreach ($fields as $i => $field) {
    echo "  [$i] " . substr($field, 0, 50) . "\n";
}
