<?php
require __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\DB;

// Arquivo de importação
$importFile = __DIR__ . '/../storage/imports/Importe anterior/PATRIMONIO.TXT';
if (!file_exists($importFile)) {
    echo "❌ Arquivo não encontrado: $importFile\n";
    exit(1);
}

// Ler arquivo e extrair NUPATRIMONIO
$handle = fopen($importFile, 'r');
$fileIds = [];
$lineCount = 0;
while (($line = fgets($handle)) !== false) {
    $lineCount++;
    // Buscar NUPATRIMONIO no início (um ou mais dígitos)
    if (preg_match('/^\s*(\d+)\b/u', $line, $m)) {
        $id = intval($m[1]);
        if ($id > 0) {  // Descartar linhas não numéricas (header, etc)
            $fileIds[$id] = 1;
        }
    }
}
fclose($handle);

$fileUniqueCount = count($fileIds);
echo "\n========================================\n";
echo "ANÁLISE DE IMPORTAÇÃO DE PATRIMÔNIOS\n";
echo "========================================\n";
echo "\n📄 ARQUIVO DE IMPORTAÇÃO:\n";
echo "   Arquivo: $importFile\n";
echo "   Linhas lidas: $lineCount\n";
echo "   NUPATRIMONIO únicos encontrados: $fileUniqueCount\n";

// Contar na tabela patr local
$dbCount = DB::table('patr')->count();
$dbDistinct = DB::table('patr')->distinct()->count('NUPATRIMONIO');

echo "\n💾 BANCO DE DADOS LOCAL (patr):\n";
echo "   Total de registros: $dbCount\n";
echo "   NUPATRIMONIO distintos: $dbDistinct\n";

// Comparação
echo "\n📊 COMPARAÇÃO:\n";
echo "   IDs no arquivo: " . $fileUniqueCount . "\n";
echo "   IDs no DB: " . $dbDistinct . "\n";
echo "   Diferença: " . ($dbDistinct - $fileUniqueCount) . " " . (($dbDistinct - $fileUniqueCount) > 0 ? "(MAIS no DB)" : "(MENOS no DB)") . "\n";

// IDs do banco
$dbIds = DB::table('patr')->distinct()->pluck('NUPATRIMONIO')->mapWithKeys(function($id) {
    return [$id => 1];
})->toArray();

// IDs faltantes no banco (existem no arquivo mas não no DB)
$missing = array_diff_key($fileIds, $dbIds);
$missingCount = count($missing);

// IDs extras no banco (existem no DB mas não no arquivo)
$extra = array_diff_key($dbIds, $fileIds);
$extraCount = count($extra);

echo "\n⚠️  DISCREPÂNCIAS:\n";
echo "   Patrimônios no arquivo MAS NÃO no BD: " . $missingCount . "\n";
if ($missingCount > 0 && $missingCount <= 50) {
    $missingSorted = array_keys($missing);
    sort($missingSorted);
    echo "   IDs: " . implode(', ', $missingSorted) . "\n";
} elseif ($missingCount > 50) {
    $missingSorted = array_keys($missing);
    sort($missingSorted);
    $sample = array_slice($missingSorted, 0, 20);
    echo "   Amostra (primeiros 20): " . implode(', ', $sample) . "\n";
    echo "   (Todos os " . $missingCount . " faltantes exportados abaixo)\n";
}

echo "\n   Patrimônios no BD MAS NÃO no arquivo: " . $extraCount . "\n";
if ($extraCount > 0 && $extraCount <= 50) {
    $extraSorted = array_keys($extra);
    sort($extraSorted);
    echo "   IDs: " . implode(', ', $extraSorted) . "\n";
} elseif ($extraCount > 50) {
    $extraSorted = array_keys($extra);
    sort($extraSorted);
    $sample = array_slice($extraSorted, 0, 20);
    echo "   Amostra (primeiros 20): " . implode(', ', $sample) . "\n";
    echo "   (Todos os " . $extraCount . " extras exportados abaixo)\n";
}

// Exportar listas completas para arquivos
$outputDir = __DIR__ . '/../storage/imports';
if (!is_dir($outputDir)) {
    mkdir($outputDir, 0777, true);
}

if ($missingCount > 0) {
    $missingSorted = array_keys($missing);
    sort($missingSorted);
    file_put_contents($outputDir . '/patrimonio_faltantes_db.txt', implode("\n", $missingSorted));
    echo "\n   📁 Faltantes exportados para: storage/imports/patrimonio_faltantes_db.txt\n";
}

if ($extraCount > 0) {
    $extraSorted = array_keys($extra);
    sort($extraSorted);
    file_put_contents($outputDir . '/patrimonio_extras_db.txt', implode("\n", $extraSorted));
    echo "   📁 Extras exportados para: storage/imports/patrimonio_extras_db.txt\n";
}

// Verificar duplicatas na tabela patr
$duplicates = DB::table('patr')
    ->select('NUPATRIMONIO', DB::raw('COUNT(*) as count'))
    ->groupBy('NUPATRIMONIO')
    ->having(DB::raw('COUNT(*)'), '>', 1)
    ->get();

$dupCount = $duplicates->count();
echo "\n🔄 DUPLICATAS NO BANCO:\n";
echo "   NUPATRIMONIO com múltiplos registros: $dupCount\n";
if ($dupCount > 0 && $dupCount <= 20) {
    foreach ($duplicates as $dup) {
        echo "      - NUPATRIMONIO {$dup->NUPATRIMONIO}: {$dup->count} registros\n";
    }
} elseif ($dupCount > 20) {
    $dupArray = $duplicates->pluck('NUPATRIMONIO')->toArray();
    echo "      Amostra (primeiros 10): " . implode(', ', array_slice($dupArray, 0, 10)) . "\n";
    file_put_contents($outputDir . '/patrimonio_duplicados_db.txt', implode("\n", $dupArray));
    echo "      📁 Lista completa exportada para: storage/imports/patrimonio_duplicados_db.txt\n";
}

// Resumo final
echo "\n========================================\n";
echo "CONCLUSÃO:\n";
echo "========================================\n";
if ($missingCount === 0 && $extraCount === 0 && $dupCount === 0) {
    echo "✅ PERFEITO! Todos os patrimônios do arquivo estão no BD.\n";
    echo "   Sem faltantes, sem extras, sem duplicatas.\n";
} else {
    if ($missingCount > 0) {
        echo "⚠️  " . $missingCount . " patrimônios do arquivo NÃO estão no BD (faltam importar)\n";
    }
    if ($extraCount > 0) {
        echo "⚠️  " . $extraCount . " patrimônios no BD NÃO estão no arquivo (extras/anteriores)\n";
    }
    if ($dupCount > 0) {
        echo "⚠️  " . $dupCount . " NUPATRIMONIO duplicados no BD (revisar)\n";
    }
}
echo "\n";
exit(0);
