<?php
require __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

// Obter estrutura da tabela
$columns = Schema::getColumns('patr');

echo "Colunas da tabela 'patr':\n";
echo "========================\n";
foreach ($columns as $column) {
    echo $column['name'] . " (" . $column['type'] . ")\n";
}

// Amostra de um registro existente
echo "\n\nAmostra de um registro existente:\n";
echo "==================================\n";
$sample = DB::table('patr')->first();
if ($sample) {
    foreach ((array)$sample as $key => $value) {
        echo "$key: $value\n";
    }
}
exit(0);
