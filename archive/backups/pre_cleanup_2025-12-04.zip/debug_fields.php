<?php
$file = 'storage/imports/Importe anterior/PATRIMONIO.TXT';
$lines = file($file, FILE_IGNORE_NEW_LINES);

// Dados linha 3
$data = $lines[2];
echo "Linha completa:\n$data\n\n";

// Remover NUPATRIMONIO
preg_match('/^(\d+)/', $data, $matches);
$nu = $matches[1];
$rest = substr($data, strlen((string)$nu));
$rest = trim($rest);

echo "Após remover NUPATRIMONIO:\n$rest\n\n";

// Split com 2+ espaços
$fields = preg_split('/\s{2,}/', $rest, 16, PREG_SPLIT_NO_EMPTY);
echo "Total de campos: " . count($fields) . "\n";
echo "Campos:\n";
foreach ($fields as $i => $f) {
    echo "$i: '" . trim($f) . "'\n";
}

echo "\n=== MAPEAMENTO ESPERADO ===\n";
echo "0 (SITUACAO): " . $fields[0] . "\n";
echo "1 (MARCA): " . $fields[1] . "\n";
echo "2 (CDLOCAL): " . $fields[2] . "\n";
echo "3 (MODELO): " . $fields[3] . "\n";
echo "4 (COR): " . $fields[4] . "\n";
echo "5 (DTAQUISICAO): " . $fields[5] . "\n";
echo "6 (DEHISTORICO): " . $fields[6] . "\n";
echo "7 (CDMATRFUNCIONARIO): " . $fields[7] . "\n";
echo "8 (CDPROJETO): " . $fields[8] . "\n";
echo "9 (NUDOCFISCAL - PULAR): " . $fields[9] . "\n";
echo "10 (USUARIO): " . (isset($fields[10]) ? $fields[10] : 'FALTA') . "\n";
echo "11 (DTOPERACAO): " . (isset($fields[11]) ? $fields[11] : 'FALTA') . "\n";
?>
