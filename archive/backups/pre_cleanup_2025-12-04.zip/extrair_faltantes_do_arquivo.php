<?php
require __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\DB;

// IDs faltantes
$missingIds = [133838, 139046, 139865, 169501, 179918, 185895];

// Arquivo de importação
$importFile = __DIR__ . '/../storage/imports/Importe anterior/PATRIMONIO.TXT';
if (!file_exists($importFile)) {
    echo "❌ Arquivo não encontrado: $importFile\n";
    exit(1);
}

// Ler arquivo linha por linha
$handle = fopen($importFile, 'r');
$missingRecords = [];
$headerLine = '';
$lineCount = 0;

while (($line = fgets($handle)) !== false) {
    $lineCount++;
    
    // Pular linhas vazias
    if (trim($line) === '') continue;
    
    // Guardar header
    if ($lineCount === 1 || strpos($line, '===') !== false || strpos($line, 'NUPATRIMONIO') !== false) {
        $headerLine = trim($line);
        continue;
    }
    
    // Buscar NUPATRIMONIO no início
    if (preg_match('/^\s*(\d+)\s+(.*)$/u', $line, $m)) {
        $id = intval($m[1]);
        if (in_array($id, $missingIds)) {
            $missingRecords[$id] = trim($line);
            echo "✅ Encontrado na linha $lineCount: NUPATRIMONIO $id\n";
        }
    }
}
fclose($handle);

echo "\n📋 Patrimônios encontrados no arquivo: " . count($missingRecords) . " de " . count($missingIds) . "\n";
if (count($missingRecords) < count($missingIds)) {
    $found = array_keys($missingRecords);
    $notFound = array_diff($missingIds, $found);
    echo "⚠️  Não encontrados: " . implode(', ', $notFound) . "\n";
}

// Exportar para arquivo de dados brutos
$outputFile = __DIR__ . '/../storage/imports/patrimonio_faltantes_dados.txt';
file_put_contents($outputFile, "Registros faltantes encontrados no arquivo de importação:\n");
file_put_contents($outputFile, str_repeat("=", 80) . "\n", FILE_APPEND);
file_put_contents($outputFile, $headerLine . "\n", FILE_APPEND);
file_put_contents($outputFile, str_repeat("=", 80) . "\n", FILE_APPEND);
foreach ($missingRecords as $id => $record) {
    file_put_contents($outputFile, $record . "\n", FILE_APPEND);
}

echo "\n📁 Dados exportados para: $outputFile\n";
echo "\nOs dados acima serão importados na próxima etapa.\n";
exit(0);
