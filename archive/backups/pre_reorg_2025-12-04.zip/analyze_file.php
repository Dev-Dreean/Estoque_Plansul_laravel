<?php
$file = 'storage/imports/Importe anterior/PATRIMONIO.TXT';
$lines = file($file, FILE_IGNORE_NEW_LINES);

// Pular header e separator
echo "=== ANÁLISE DO ARQUIVO ===\n\n";

// Linha do header
$header = $lines[0];
echo "HEADER:\n$header\n\n";

// Linha de dados 1
$data1 = trim($lines[2]);
echo "DADOS 1:\n$data1\n\n";

// Fazer split como o código faz
echo "=== SPLIT COM 2+ ESPAÇOS ===\n";
$trimmed = trim($data1);
if (preg_match('/^(\d+)/', $trimmed, $matches)) {
    $nu = $matches[1];
    echo "NUPATRIMONIO: $nu\n";
    $rest = substr($trimmed, strlen((string)$nu));
    $rest = trim($rest);
    $fields = preg_split('/\s{2,}/', $rest, 16, PREG_SPLIT_NO_EMPTY);
    
    echo "Número de campos extraídos: " . count($fields) . "\n\n";
    foreach ($fields as $i => $field) {
        echo "[$i] = '" . substr($field, 0, 50) . "'\n";
    }
}
?>
