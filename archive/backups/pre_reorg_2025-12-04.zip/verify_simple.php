<?php
// Conexão direta ao banco (sem Laravel)
$host = getenv('DB_HOST') ?: '127.0.0.1';
$user = getenv('DB_USERNAME') ?: 'root';
$pass = getenv('DB_PASSWORD') ?: '';
$db = getenv('DB_DATABASE') ?: 'cadastros_plansul';

$conn = new mysqli($host, $user, $pass, $db);
$conn->set_charset('utf8mb4');

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Total
$result = $conn->query('SELECT COUNT(*) as total FROM patr');
$row = $result->fetch_assoc();
echo "Total de registros: " . $row['total'] . "\n\n";

// Patrimônio 17546
$result = $conn->query('SELECT NUPATRIMONIO, CDLOCAL, CDPROJETO, SITUACAO, MARCA FROM patr WHERE NUPATRIMONIO = 17546');
$row = $result->fetch_assoc();
if ($row) {
    echo "Patrimônio 17546:\n";
    echo "  CDLOCAL: " . $row['CDLOCAL'] . "\n";
    echo "  CDPROJETO: " . $row['CDPROJETO'] . "\n";
    echo "  SITUACAO: " . $row['SITUACAO'] . "\n";
    echo "  MARCA: " . $row['MARCA'] . "\n\n";
}

// Patrimônio 19269
$result = $conn->query('SELECT NUPATRIMONIO, CDLOCAL, CDPROJETO, SITUACAO, DEHISTORICO, DTOPERACAO FROM patr WHERE NUPATRIMONIO = 19269');
$row = $result->fetch_assoc();
if ($row) {
    echo "Patrimônio 19269:\n";
    echo "  CDLOCAL: " . $row['CDLOCAL'] . "\n";
    echo "  CDPROJETO: " . $row['CDPROJETO'] . "\n";
    echo "  SITUACAO: " . $row['SITUACAO'] . "\n";
    echo "  DEHISTORICO: " . $row['DEHISTORICO'] . "\n";
    echo "  DTOPERACAO: " . $row['DTOPERACAO'] . "\n\n";
}

// Patrimônio 224
$result = $conn->query('SELECT NUPATRIMONIO, CDLOCAL, SITUACAO, MARCA FROM patr WHERE NUPATRIMONIO = 224 LIMIT 1');
$row = $result->fetch_assoc();
if ($row) {
    echo "Patrimônio 224:\n";
    echo "  CDLOCAL: " . $row['CDLOCAL'] . "\n";
    echo "  SITUACAO: " . $row['SITUACAO'] . "\n";
    echo "  MARCA: " . $row['MARCA'] . "\n\n";
}

// Datas (amostra)
$result = $conn->query('SELECT NUPATRIMONIO, DTAQUISICAO, DTOPERACAO FROM patr WHERE DTAQUISICAO IS NOT NULL LIMIT 5');
echo "Amostra de datas (formato YYYY-MM-DD):\n";
while ($row = $result->fetch_assoc()) {
    echo "  " . $row['NUPATRIMONIO'] . ": DTAQUISICAO=" . $row['DTAQUISICAO'] . ", DTOPERACAO=" . $row['DTOPERACAO'] . "\n";
}

echo "\n=== VERIFICAÇÃO COMPLETA ===\n";
$conn->close();
?>
