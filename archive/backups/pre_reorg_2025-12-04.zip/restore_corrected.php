<?php
// Antes de executar o novo import, vamos restaurar os registros que foram corrigidos
// Patrimônio 17546 deveria ter CDLOCAL=109, CDPROJETO=100001

$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db = 'cadastros_plansul';

$conn = new mysqli($host, $user, $pass, $db);
$conn->set_charset('utf8mb4');

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Restaurar patrimônio 17546
$sql = "UPDATE patr SET CDLOCAL = 109 WHERE NUPATRIMONIO = 17546";
if ($conn->query($sql)) {
    echo "✓ Patrimônio 17546: CDLOCAL restaurado para 109\n";
} else {
    echo "✗ Erro ao restaurar 17546: " . $conn->error . "\n";
}

// Restaurar patrimônio 19269 - deveria ter CDLOCAL=1422, CDPROJETO=200
$sql = "UPDATE patr SET CDLOCAL = 1422, CDPROJETO = 200 WHERE NUPATRIMONIO = 19269";
if ($conn->query($sql)) {
    echo "✓ Patrimônio 19269: CDLOCAL=1422, CDPROJETO=200 restaurados\n";
} else {
    echo "✗ Erro ao restaurar 19269: " . $conn->error . "\n";
}

echo "\nAgora execute: php artisan patrimonios:importar-todos\n";

$conn->close();
?>
