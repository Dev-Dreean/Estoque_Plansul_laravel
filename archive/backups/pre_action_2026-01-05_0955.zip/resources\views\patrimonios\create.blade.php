<x-app-layout>
  {{-- Abas de navegaÇõÇœo do patrimÇïnio --}}
  <x-patrimonio-nav-tabs />

  @include('patrimonios.partials.form-create')
</x-app-layout>
