<x-app-layout>
  {{-- Abas de navegação do patrimônio --}}
  <x-patrimonio-nav-tabs />

  <div class="max-w-6xl mx-auto p-6">
    <h1 class="text-2xl font-bold mb-4">Teste: Formulário Patrimônio V2</h1>
    <x-patrimonio-form-v2 />
  </div>
</x-app-layout>
